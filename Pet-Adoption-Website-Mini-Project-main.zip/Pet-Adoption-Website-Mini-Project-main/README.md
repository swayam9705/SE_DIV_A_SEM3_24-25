# Setup

Clone this repository using `git clone` command.
```bash
git clone https://github.com/swayam9705/Pet-Adoption-Website-Mini-Project.git
```

```cd``` into your folder

```bash
npm install
```

```bash
npm run dev
```
